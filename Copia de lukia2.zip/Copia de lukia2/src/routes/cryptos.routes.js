// src/routes/cryptos.routes.js intentionally left blank (placeholder)

