// src/routes/auth.routes.js intentionally left blank (placeholder)

