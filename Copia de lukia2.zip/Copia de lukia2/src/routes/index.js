// src/routes/index.js intentionally left blank (placeholder)

// src/routes/index.js
const express = require('express');
const router = express.Router();
const marketService = require('../services/market.service');

router.get('/', async (req, res) => {
  try {
    const [cryptos, usdRate] = await Promise.all([
      marketService.getCryptoPrices(),
      marketService.getUsdToCop()
    ]);

    const usdToCop = usdRate && usdRate.rates ? usdRate.rates.COP : null;
    const now = new Date();

    res.render('pages/index', {
      market: {
        cryptos,
        usdToCop
      },
      updatedAt: now.toISOString()
    });
  } catch (err) {
    console.error('Error fetching market data:', err.message || err);
    // Puedes renderizar página de error o enviar datos vacíos.
    res.render('pages/index', { market: null, updatedAt: null, error: 'No se pudo obtener datos de mercado' });
  }
});

module.exports = router;
