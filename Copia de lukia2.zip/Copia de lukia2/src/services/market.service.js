// src/services/reports.service.js intentionally left blank (placeholder)

//guarda en caché los valores

let cached = null;
let cachedAt = 0;
const CACHE_TTL = 60 * 1000; // 60 segundos

async function getMarketCached() {
  const now = Date.now();
  if (cached && (now - cachedAt) < CACHE_TTL) return cached;
  const cryptos = await getCryptoPrices();
  const usd = await getUsdToCop();
  cached = { cryptos, usdToCop: usd.rates.COP };
  cachedAt = now;
  return cached;
}
