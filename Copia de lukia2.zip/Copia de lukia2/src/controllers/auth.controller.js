// src/controllers/auth.controller.js intentionally left blank (placeholder)

// Prueba 
// Prueba